import { createApp } from 'vue'
import App from './App.vue'
import {sm4Encrypt,sm4Decrypt,generateKey} from './js/sm4crypt.js'  //sm4加密,解密
import {sm2Encrypt,sm2Decrypt,publicKey,privateKey} from './js/sm2crypt.js'  //sm2加密,解密
    var key1 = generateKey();
    console.log('sm2公钥')
    console.log(publicKey)
    console.log('sm2私钥')
    console.log(privateKey)
    console.log('sm4密钥')
    console.log(key1)
    var data = {
      addTime: null,
      amount: 100010,
      nickname: "zhm",
      arrau:[{name:'zhangsan',age:14},{name:'lisi',age:20}]
    }
    console.log('sm2------------------------------------------加密')
    console.log(sm2Encrypt(data))
    var enData = sm2Encrypt(data)
    console.log('sm2------------------------------------------解密')
    console.log(sm2Decrypt(enData))
    console.log('sm4------------------------------------------')
    // var key = 'CCB545A588D21C94C8749C0D4528A79F'
    var key = key1.toString()

    console.log(key.length)
    console.log('sm4------------------------------------------加密')
    console.log(sm4Encrypt(key,data))
    console.log('sm4------------------------------------------解密')
    var newdata = sm4Decrypt('BCA423281B54718F5328954808CC9942','3BB2AEC04E62F634AFE53BD7C2F46809B5BCF72C2B1984ED85E8DCACC285421B1EC4D330E4B35499FDA3AB3EE91134574272641C91276F86CEDDF9C16656F9CF7179FBAF02580E883E5038DCAE00C69A91C6A2A4E0DA9D8920644D7F0D851569990C66D0E13BD70D62448565A7DFC24FD9A7A9A26E751D482F180F32FDC68A6B')
    // console.log(decrypt(key,'083A5BCCBFBBD7AC9AD61B91261E998883B9658005C1E4F9BC45962359F18238A95264478ACE067C639128D523A3583F12E99E26E4C9C6EE365312213A63A82F'))
    console.log(newdata)

createApp(App).mount('#app')
